package com.example.demo02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
