package com.example.demo03.dto;

import lombok.Data;
@Data
public class AuthDTO {
	private String userid;
	private String auth;
}
