package com.example.tour.model;

import java.util.Date;

public class accomment {

	private Long accnum;
	private String acwriter;
	private Date acregdate;
	private String accontent;
	private Long acbnum;
	
}
