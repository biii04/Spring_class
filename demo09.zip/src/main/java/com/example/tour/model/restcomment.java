package com.example.tour.model;

import java.util.Date;

public class restcomment {

	private Long recnum;
	private String rewriter;
	private Date reregdate;
	private String recontent;
	private Long rebnum;
	
}
