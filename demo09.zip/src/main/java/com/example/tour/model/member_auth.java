package com.example.tour.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class member_auth {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long num;
	@ManyToOne
	@JoinColumn(name = "userid")
	private Long userid;
	private String role;
}
