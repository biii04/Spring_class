package com.example.tour.model;

import java.util.Date;

public class restboard {

	private Long renum;
	private String retitle;
	private String recontent;
	private Date reregdate;
	private String rewriter;
	private Long rereplycnt;
	private Long rehitcnt;
	private String refilename;
	private String reregion;
	
}
