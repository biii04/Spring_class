package com.example.tour.model;

import java.util.Date;

public class tourcomment {

	private Long tcnum;
	private String twriter;
	private Date tregdate;
	private String tcontent;
	private Long tbnum;
	
}
