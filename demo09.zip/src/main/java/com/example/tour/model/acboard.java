package com.example.tour.model;

import java.util.Date;

public class acboard {

	private Long acnum;
	private String actitle;
	private String accontent;
	private Date acregdate;
	private String acwriter;
	private Long acreplycnt;
	private Long achitcnt;
	private String acfilename;
	private String acregion;
	
	
}
