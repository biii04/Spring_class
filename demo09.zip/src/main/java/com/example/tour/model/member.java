package com.example.tour.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class member {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userid")
	private Long userid;
	private String pwd;
	private String username;
	private String age;
	private String email;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
	private Date regdate;
	private String city;
	@Column(nullable = false)
	private String id;
	//private String role;
	
}
