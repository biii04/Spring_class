package com.example.tour.model;

import java.util.Date;

public class tourboard {

	private Long tnum;
	private String ttitle;
	private String tcontent;
	private Date tregdate;
	private String twriter;
	private Long treplycnt;
	private Long thitcnt;
	private String tfilename;
	private String tregion;
	
}
