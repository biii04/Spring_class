package com.example.tour.model;

import java.util.Date;

public class freecomment {

	private Long fcnum;
	private String fwriter;
	private Date fregdate;
	private String fcontent;
	private Long fbnum;
	
}
