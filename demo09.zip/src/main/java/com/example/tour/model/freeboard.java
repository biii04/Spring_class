package com.example.tour.model;

import java.util.Date;

public class freeboard {

	private Long num;
	private String title;
	private String content;
	private Date regdate;
	private String writer;
	private String replycnt;
	private String hitcnt;
	
}
